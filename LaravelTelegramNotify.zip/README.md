# Laravel Telegram Bot Notifier

This Laravel app sends notifications to a Telegram chat or group when:
- A new user registers
- An admin sends a message via a form

## Setup
1. Clone the repo
2. Copy `.env.example` to `.env` and add your Telegram Bot Token & Chat ID
3. Run migrations & serve the app

## Telegram Bot Setup
- Create a bot via @BotFather
- Get the bot token
- Get your chat ID via the Telegram API `getUpdates`

## Routes
- POST `/admin/send-telegram` - Send custom message to Telegram

Happy coding!

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class TelegramController extends Controller
{
    public function sendMessage($message)
    {
        $botToken = env('TELEGRAM_BOT_TOKEN');
        $chatId = env('TELEGRAM_CHAT_ID');

        Http::get("https://api.telegram.org/bot$botToken/sendMessage", [
            'chat_id' => $chatId,
            'text' => $message,
        ]);
    }

    public function notifyNewUser($user)
    {
        $message = "🧑‍💻 New user registered:\nName: {$user->name}\nEmail: {$user->email}";
        $this->sendMessage($message);
    }

    public function adminSend(Request $request)
    {
        $this->sendMessage("📢 Admin Message: " . $request->message);
        return back()->with('status', 'Message sent to Telegram!');
    }
}

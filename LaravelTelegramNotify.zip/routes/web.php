<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\TelegramController;

Route::post('/admin/send-telegram', [TelegramController::class, 'adminSend'])->name('admin.send.telegram');
